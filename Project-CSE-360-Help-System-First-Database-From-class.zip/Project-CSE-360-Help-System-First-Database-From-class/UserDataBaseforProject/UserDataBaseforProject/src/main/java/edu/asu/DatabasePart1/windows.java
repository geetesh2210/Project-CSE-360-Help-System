package edu.asu.DatabasePart1;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class windows{

    private Stage primaryStage;
    private String adminUsername;

    public windows(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public Pane getCreateAdminAccountPane() {
        Pane pane = new Pane();

        Label title = new Label("Create Admin Account");
        title.setFont(Font.font("Arial", 25));
        title.setLayoutY(40);
        title.setLayoutX(200);

        TextField username = new TextField();
        username.setPromptText("Create Username");
        username.setLayoutX(250);
        username.setLayoutY(100);

        PasswordField password = new PasswordField();
        password.setPromptText("Create Password");
        password.setLayoutX(250);
        password.setLayoutY(150);

        PasswordField passCheck = new PasswordField();
        passCheck.setPromptText("Re-enter Password");
        passCheck.setLayoutX(250);
        passCheck.setLayoutY(200);

        Button createButton = new Button("Create");
        createButton.setLayoutX(300);
        createButton.setLayoutY(250);
        createButton.setOnAction(e -> {
            adminUsername = username.getText();
            primaryStage.setScene(new Scene(getFinishSetupAccountPane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        pane.getChildren().addAll(title, username, password, passCheck, createButton);
        return pane;
    }

    public Pane getFinishSetupAccountPane() {
        Pane pane = new Pane();

        Label title = new Label("Finish Setting Up Account");
        title.setFont(Font.font("Arial", 25));
        title.setLayoutY(40);
        title.setLayoutX(150);

        Label usernameLabel = new Label("Username: " + adminUsername);
        usernameLabel.setLayoutX(250);
        usernameLabel.setLayoutY(100);

        TextField email = new TextField();
        email.setPromptText("Enter Email");
        email.setLayoutX(250);
        email.setLayoutY(150);

        TextField firstName = new TextField();
        firstName.setPromptText("First Name");
        firstName.setLayoutX(250);
        firstName.setLayoutY(200);

        TextField middleName = new TextField();
        middleName.setPromptText("Middle Name");
        middleName.setLayoutX(250);
        middleName.setLayoutY(250);

        TextField lastName = new TextField();
        lastName.setPromptText("Last Name");
        lastName.setLayoutX(250);
        lastName.setLayoutY(300);

        TextField preferredName = new TextField();
        preferredName.setPromptText("Preferred Name");
        preferredName.setLayoutX(250);
        preferredName.setLayoutY(350);

        Button finishButton = new Button("Finish");
        finishButton.setLayoutX(300);
        finishButton.setLayoutY(400);
        finishButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(getLoginPane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        pane.getChildren().addAll(title, usernameLabel, email, firstName, middleName, lastName, preferredName, finishButton);
        return pane;
    }

    public Pane getLoginPane() {
        Pane pane = new Pane();

        Label title = new Label("Log In");
        title.setFont(Font.font("Arial", 25));
        title.setLayoutY(40);
        title.setLayoutX(300);

        TextField username = new TextField();
        username.setPromptText("Username");
        username.setLayoutX(250);
        username.setLayoutY(100);

        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        password.setLayoutX(250);
        password.setLayoutY(150);

        Button loginButton = new Button("Log In");
        loginButton.setLayoutX(300);
        loginButton.setLayoutY(200);
        loginButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(getHomePane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        Button createAccountButton = new Button("Create Account");
        createAccountButton.setLayoutX(290);
        createAccountButton.setLayoutY(250);
        createAccountButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(getCreateAccountPane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        pane.getChildren().addAll(title, username, password, loginButton, createAccountButton);
        return pane;
    }

    public Pane getCreateAccountPane() {
        Pane pane = new Pane();

        Label title = new Label("Create Account");
        title.setFont(Font.font("Arial", 25));
        title.setLayoutY(40);
        title.setLayoutX(250);

        TextField username = new TextField();
        username.setPromptText("Create Username");
        username.setLayoutX(250);
        username.setLayoutY(100);

        PasswordField password = new PasswordField();
        password.setPromptText("Create Password");
        password.setLayoutX(250);
        password.setLayoutY(150);

        PasswordField passCheck = new PasswordField();
        passCheck.setPromptText("Re-enter Password");
        passCheck.setLayoutX(250);
        passCheck.setLayoutY(200);

        Button createButton = new Button("Create");
        createButton.setLayoutX(300);
        createButton.setLayoutY(250);
        createButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(getFinishSetupAccountPane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        pane.getChildren().addAll(title, username, password, passCheck, createButton);
        return pane;
    }

    public Pane getHomePane() {
        Pane pane = new Pane();

        Button logOutButton = new Button("Log Out");
        logOutButton.setLayoutX(50);
        logOutButton.setLayoutY(450);
        logOutButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(getLoginPane(), Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT));
        });

        pane.getChildren().add(logOutButton);
        return pane;
    }
}

	
	
	
