package edu.asu.DatabasePart1;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public class RoleSelectionScene {

    private Scene scene;
    private SceneController controller;
    private String username;

    public RoleSelectionScene(SceneController controller) {
        this.controller = controller;
        this.username = username;
        Pane pane = new Pane();
        Label label = new Label("Select Role");
        label.setFont(Font.font("Arial", 25));
        label.setLayoutX(250);
        label.setLayoutY(100);

        Button instructorButton = new Button("Instructor");
        instructorButton.setLayoutX(200);
        instructorButton.setLayoutY(200);
        instructorButton.setOnAction(e -> {
            // Switch to instructor home screen
            controller.switchToHomeScene();
        });

        Button studentButton = new Button("Student");
        studentButton.setLayoutX(400);
        studentButton.setLayoutY(200);
        studentButton.setOnAction(e -> {
            // Switch to student home screen
            controller.switchToHomeScene();
        });

        pane.getChildren().addAll(label, instructorButton, studentButton);
        this.scene = new Scene(pane, 700, 500);
    }

    public Scene getScene() {
        return this.scene;
    }
}